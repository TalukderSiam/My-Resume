var typed = new Typed(".typing",{
    strings: ["Student", "Web Developer", "Programmer"],
    typeSpeed: 80,
    backSpeed: 80,
});

var typed = new Typed(".typing-2",{
    strings: ["Student", "Web Developer", "Programmer"],
    typeSpeed: 80,
    backSpeed: 80,
});